'use client';
import React, { useState } from 'react';
import { Sparkles, Send, Loader2, ChevronDown, ChevronUp } from 'lucide-react';


// BACKEND: POST /api/ai/chat with { message, studentId } → streamed AI response

const QUICK_PROMPTS = [
  { id: 'qp-1', label: 'What should I study today?' },
  { id: 'qp-2', label: 'Explain SN1 vs SN2 reactions' },
  { id: 'qp-3', label: 'Create a revision plan for my exam' },
  { id: 'qp-4', label: 'Where am I weakest this week?' },
];

const AI_GREETING = "Hi Priya! 👋 Based on your progress, I recommend focusing on Nucleophilic Substitution today — it's a high-weightage topic for your exam in 8 days. Want me to break it down step by step?";

interface Message {
  id: string;
  role: 'ai' | 'user';
  text: string;
}

export default function AIGuidePanel() {
  const [expanded, setExpanded] = useState(true);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: 'msg-greeting', role: 'ai', text: AI_GREETING },
  ]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: `msg-user-${Date.now()}`, role: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    // BACKEND: POST /api/ai/chat → AI response
    await new Promise((r) => setTimeout(r, 1200));
    const aiResponses: Record<string, string> = {
      'What should I study today?': "Today I recommend: 1) Nucleophilic Substitution (25 min), 2) Integration by Substitution review (15 min), 3) Quick test on Thermodynamics Chapter 4. This covers your weakest areas before the exam! 🎯",
      'Explain SN1 vs SN2 reactions': "SN1 (Unimolecular): Two-step reaction, forms a carbocation intermediate, favored by tertiary substrates & polar protic solvents. Rate = k[substrate]. SN2 (Bimolecular): One-step backside attack, favored by primary substrates & polar aprotic solvents. Rate = k[substrate][nucleophile]. Key difference: SN1 gives racemization, SN2 gives inversion! 🔬",
      'Create a revision plan for my exam': "7-Day Exam Plan:\n📅 Day 1-2: Reaction Mechanisms (Ch. 4-5)\n📅 Day 3: Stereochemistry (Ch. 6)\n📅 Day 4: Carbonyl Chemistry (Ch. 8)\n📅 Day 5: Practice test + doubt clearing\n📅 Day 6: Weak topic revision\n📅 Day 7: Formula sheet review + rest 💪",
      'Where am I weakest this week?': "Based on your test scores, you're weakest in: 1) Integration techniques (58% avg), 2) Reaction mechanisms (63% avg). Your strongest area is Thermodynamics (78%). I suggest 2 extra practice sessions on Integration before Friday! 📊",
    };
    const reply = aiResponses[text] || "Great question! Let me analyze your study data and give you a personalized answer. Based on your current progress, I suggest focusing on the fundamentals first, then applying them to practice problems. Would you like me to create a focused exercise set? 💡";
    setMessages((prev) => [...prev, { id: `msg-ai-${Date.now()}`, role: 'ai', text: reply }]);
    setLoading(false);
  };

  return (
    <div className="card overflow-hidden">
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-primary flex items-center justify-center">
            <Sparkles size={14} className="text-white" />
          </div>
          <div className="text-left">
            <p className="text-sm font-semibold text-foreground">AI Study Guide</p>
            <p className="text-[10px] text-muted-foreground">Powered by StudyAI</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="badge bg-success-soft text-success">Online</span>
          {expanded ? <ChevronUp size={15} className="text-muted-foreground" /> : <ChevronDown size={15} className="text-muted-foreground" />}
        </div>
      </button>

      {expanded && (
        <div className="animate-slide-up">
          {/* Messages */}
          <div className="px-4 pb-3 space-y-3 max-h-52 overflow-y-auto scrollbar-thin">
            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-3 py-2 text-xs leading-relaxed whitespace-pre-line ${
                    m.role === 'ai' ?'bg-primary-soft text-foreground rounded-tl-sm' :'bg-primary text-white rounded-tr-sm'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-primary-soft rounded-2xl rounded-tl-sm px-3 py-2 flex items-center gap-1.5">
                  <Loader2 size={12} className="animate-spin text-primary" />
                  <span className="text-xs text-muted-foreground">Thinking…</span>
                </div>
              </div>
            )}
          </div>

          {/* Quick Prompts */}
          <div className="px-4 pb-3 flex flex-wrap gap-1.5">
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q.id}
                onClick={() => handleSend(q.label)}
                disabled={loading}
                className="text-[10px] font-medium text-primary bg-primary-soft px-2.5 py-1 rounded-full hover:bg-primary hover:text-white transition-all duration-150 disabled:opacity-50"
              >
                {q.label}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="px-4 pb-4 flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(input); }}}
              placeholder="Ask anything about your studies…"
              className="input-field text-xs py-2"
              disabled={loading}
            />
            <button
              onClick={() => handleSend(input)}
              disabled={loading || !input.trim()}
              className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center text-white flex-shrink-0 hover:opacity-90 active:scale-95 transition-all duration-150 disabled:opacity-50"
            >
              {loading ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}