'use client';
import React from 'react';
import { Flame, BookMarked, Trophy, MessageCircleCheck, Clock, CalendarClock, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


// Grid plan: 6 cards → grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 2xl:grid-cols-6
// Row 1 (desktop): all 6 cards in one row, hero card (streak) spans 2 cols on md/lg

const METRICS = [
  {
    id: 'metric-streak',
    label: 'Study Streak',
    value: '12',
    unit: 'days',
    sub: 'Personal best: 18 days',
    icon: Flame,
    trend: 'up',
    trendVal: '+2 from last week',
    color: 'bg-orange-50 border-orange-100',
    iconColor: 'text-orange-500',
    iconBg: 'bg-orange-100',
    valueColor: 'text-orange-600',
    hero: true,
  },
  {
    id: 'metric-topics',
    label: 'Topics Mastered',
    value: '84',
    unit: 'topics',
    sub: 'This semester',
    icon: BookMarked,
    trend: 'up',
    trendVal: '+6 this week',
    color: 'bg-card border-border',
    iconColor: 'text-primary',
    iconBg: 'bg-primary-soft',
    valueColor: 'text-foreground',
    hero: false,
  },
  {
    id: 'metric-score',
    label: 'Avg Test Score',
    value: '76',
    unit: '%',
    sub: 'Across 14 tests',
    icon: Trophy,
    trend: 'down',
    trendVal: '-4% from last month',
    color: 'bg-danger-soft/30 border-danger/20',
    iconColor: 'text-danger',
    iconBg: 'bg-danger-soft',
    valueColor: 'text-danger',
    hero: false,
  },
  {
    id: 'metric-doubts',
    label: 'Doubts Resolved',
    value: '31',
    unit: 'solved',
    sub: '3 pending today',
    icon: MessageCircleCheck,
    trend: 'up',
    trendVal: '+5 this week',
    color: 'bg-card border-border',
    iconColor: 'text-success',
    iconBg: 'bg-success-soft',
    valueColor: 'text-foreground',
    hero: false,
  },
  {
    id: 'metric-hours',
    label: 'Weekly Study Hours',
    value: '14.5',
    unit: 'hrs',
    sub: 'Goal: 20 hrs/week',
    icon: Clock,
    trend: 'neutral',
    trendVal: '72% of weekly goal',
    color: 'bg-warning-soft/40 border-warning/20',
    iconColor: 'text-warning',
    iconBg: 'bg-warning-soft',
    valueColor: 'text-warning',
    hero: false,
  },
  {
    id: 'metric-exam',
    label: 'Next Exam',
    value: '8',
    unit: 'days',
    sub: 'Organic Chemistry — Sem 4',
    icon: CalendarClock,
    trend: 'neutral',
    trendVal: 'Apr 30, 2026',
    color: 'bg-info-soft/40 border-info/20',
    iconColor: 'text-info',
    iconBg: 'bg-info-soft',
    valueColor: 'text-info',
    hero: false,
  },
];

const TrendIcon = ({ trend }: { trend: string }) => {
  if (trend === 'up') return <TrendingUp size={11} className="text-success" />;
  if (trend === 'down') return <TrendingDown size={11} className="text-danger" />;
  return <Minus size={11} className="text-muted-foreground" />;
};

export default function MetricsBentoGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-6 2xl:grid-cols-6 gap-4">
      {METRICS.map((m) => {
        const Icon = m.icon;
        return (
          <div
            key={m.id}
            className={`card border p-4 xl:p-5 flex flex-col gap-3 hover:shadow-card-hover transition-shadow duration-200 ${m.color} ${m.hero ? 'md:col-span-1' : ''}`}
          >
            <div className="flex items-center justify-between">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${m.iconBg}`}>
                <Icon size={16} className={m.iconColor} />
              </div>
              <div className="flex items-center gap-1">
                <TrendIcon trend={m.trend} />
              </div>
            </div>
            <div>
              <div className="flex items-baseline gap-1">
                <span className={`text-2xl xl:text-3xl font-bold tabular-nums ${m.valueColor}`}>{m.value}</span>
                <span className="text-xs text-muted-foreground font-medium">{m.unit}</span>
              </div>
              <p className="text-[11px] font-semibold text-muted-foreground tracking-wide uppercase mt-0.5">{m.label}</p>
            </div>
            <div className="mt-auto">
              <p className="text-[11px] text-muted-foreground leading-relaxed">{m.sub}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-1">
                <TrendIcon trend={m.trend} /> {m.trendVal}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}