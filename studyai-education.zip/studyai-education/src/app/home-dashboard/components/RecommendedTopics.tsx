'use client';
import React from 'react';
import Link from 'next/link';
import { Clock, Zap, ChevronRight } from 'lucide-react';
import Badge from '@/components/ui/Badge';

// BACKEND: fetch /api/recommendations/topics for this student (AI-powered suggestions)

const RECOMMENDED = [
  {
    id: 'rec-1',
    subject: 'Organic Chemistry',
    topic: 'Nucleophilic Substitution (SN1 & SN2)',
    chapter: 'Chapter 5 — Reaction Mechanisms',
    estimatedTime: '25 min',
    priority: 'high',
    reason: 'Exam in 8 days — this topic has high weightage',
    completion: 0,
    subjectColor: 'bg-purple-50 text-purple-600',
  },
  {
    id: 'rec-2',
    subject: 'Calculus',
    topic: 'Integration by Substitution',
    chapter: 'Chapter 8 — Integration Techniques',
    estimatedTime: '30 min',
    priority: 'medium',
    reason: 'You scored 58% on this in the last test',
    completion: 30,
    subjectColor: 'bg-amber-50 text-amber-600',
  },
  {
    id: 'rec-3',
    subject: 'Thermodynamics',
    topic: 'Carnot Cycle and Efficiency',
    chapter: 'Chapter 4 — Second Law',
    estimatedTime: '20 min',
    priority: 'low',
    reason: 'Next in your study schedule',
    completion: 60,
    subjectColor: 'bg-green-50 text-green-600',
  },
  {
    id: 'rec-4',
    subject: 'Data Structures',
    topic: 'AVL Tree Rotations',
    chapter: 'Chapter 7 — Balanced Trees',
    estimatedTime: '35 min',
    priority: 'medium',
    reason: 'Continue from where you left off',
    completion: 15,
    subjectColor: 'bg-blue-50 text-blue-600',
  },
];

const PRIORITY_BADGE: Record<string, React.ReactNode> = {
  high: <Badge variant="danger">High Priority</Badge>,
  medium: <Badge variant="warning">Medium</Badge>,
  low: <Badge variant="muted">Scheduled</Badge>,
};

export default function RecommendedTopics() {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Zap size={16} className="text-primary" />
          <h3 className="text-base font-semibold text-foreground">AI-Recommended Topics</h3>
        </div>
        <span className="text-xs text-muted-foreground">Based on your schedule & performance</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {RECOMMENDED.map((r) => (
          <Link
            key={r.id}
            href="/study-content"
            className="group flex flex-col gap-2.5 p-3.5 rounded-2xl border border-border hover:border-primary/30 hover:bg-primary-soft/30 hover:shadow-card-hover transition-all duration-200 cursor-pointer"
          >
            <div className="flex items-start justify-between gap-2">
              <span className={`badge ${r.subjectColor} text-[10px] font-semibold`}>{r.subject}</span>
              {PRIORITY_BADGE[r.priority]}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground leading-snug group-hover:text-primary transition-colors">{r.topic}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{r.chapter}</p>
            </div>
            <p className="text-[11px] text-muted-foreground italic leading-relaxed border-l-2 border-primary/30 pl-2">{r.reason}</p>
            <div className="flex items-center justify-between mt-1">
              <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                <Clock size={11} />
                <span>{r.estimatedTime}</span>
              </div>
              {r.completion > 0 && (
                <div className="flex items-center gap-1.5">
                  <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${r.completion}%` }} />
                  </div>
                  <span className="text-[10px] text-muted-foreground tabular-nums">{r.completion}%</span>
                </div>
              )}
              <ChevronRight size={14} className="text-muted-foreground group-hover:text-primary transition-colors ml-auto" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}