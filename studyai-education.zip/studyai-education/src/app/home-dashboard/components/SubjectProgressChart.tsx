'use client';
import React from 'react';
import { RadialBarChart, RadialBar, ResponsiveContainer, Tooltip } from 'recharts';

// BACKEND: fetch /api/subjects/progress for this student

const SUBJECT_DATA = [
  { id: 'subj-chem', name: 'Organic Chemistry', completion: 62, fill: 'hsl(258,95%,68%)' },
  { id: 'subj-math', name: 'Calculus', completion: 45, fill: 'hsl(38,92%,50%)' },
  { id: 'subj-physics', name: 'Thermodynamics', completion: 78, fill: 'hsl(142,71%,45%)' },
  { id: 'subj-cs', name: 'Data Structures', completion: 33, fill: 'hsl(210,100%,56%)' },
];

interface TooltipPayloadItem {
  payload: { name: string; completion: number };
}

const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: TooltipPayloadItem[] }) => {
  if (!active || !payload || payload.length === 0) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-card rounded-xl border border-border shadow-card px-3 py-2 text-xs">
      <p className="font-semibold text-foreground">{d.name}</p>
      <p className="text-muted-foreground mt-0.5">{d.completion}% complete</p>
    </div>
  );
};

export default function SubjectProgressChart() {
  return (
    <div className="card p-5">
      <h3 className="text-base font-semibold text-foreground mb-1">Subject Progress</h3>
      <p className="text-xs text-muted-foreground mb-4">Chapter completion this semester</p>
      <ResponsiveContainer width="100%" height={160}>
        <RadialBarChart
          cx="50%"
          cy="50%"
          innerRadius="20%"
          outerRadius="90%"
          data={SUBJECT_DATA}
          startAngle={90}
          endAngle={-270}
        >
          <RadialBar dataKey="completion" background={{ fill: 'hsl(240,10%,95%)' }} cornerRadius={6} />
          <Tooltip content={<CustomTooltip />} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="space-y-2 mt-3">
        {SUBJECT_DATA.map((s) => (
          <div key={s.id} className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: s.fill }} />
            <span className="text-xs text-muted-foreground flex-1 truncate">{s.name}</span>
            <span className="text-xs font-semibold text-foreground tabular-nums">{s.completion}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}