import React from 'react';
import { BookOpen, FlaskConical, MessageCircleCheck, Trophy, Sparkles } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


// BACKEND: fetch /api/activity/recent for this student

const ACTIVITIES = [
  { id: 'act-1', type: 'topic', icon: BookOpen, color: 'text-primary bg-primary-soft', text: 'Completed "Aldol Condensation" in Organic Chemistry', time: '14 min ago' },
  { id: 'act-2', type: 'test', icon: FlaskConical, color: 'text-warning bg-warning-soft', text: 'Scored 82% on Calculus Integration test', time: '1h ago' },
  { id: 'act-3', type: 'doubt', icon: MessageCircleCheck, color: 'text-success bg-success-soft', text: 'AI resolved doubt: "What is Le Chatelier\'s Principle?"', time: '2h ago' },
  { id: 'act-4', type: 'achievement', icon: Trophy, color: 'text-amber-500 bg-amber-50', text: 'Earned "Week Warrior" badge for 7-day streak', time: '5h ago' },
  { id: 'act-5', type: 'topic', icon: BookOpen, color: 'text-primary bg-primary-soft', text: 'Started "Binary Search Trees" in Data Structures', time: 'Yesterday' },
  { id: 'act-6', type: 'ai', icon: Sparkles, color: 'text-purple-500 bg-purple-50', text: 'AI Guide generated a custom study plan for Week 17', time: 'Yesterday' },
];

export default function RecentActivityFeed() {
  return (
    <div className="card p-5">
      <h3 className="text-base font-semibold text-foreground mb-4">Recent Activity</h3>
      <div className="space-y-3">
        {ACTIVITIES?.map((a) => {
          const Icon = a?.icon;
          return (
            <div key={a?.id} className="flex items-start gap-3">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${a?.color}`}>
                <Icon size={13} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground leading-relaxed">{a?.text}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{a?.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}