import React from 'react';
import Link from 'next/link';
import { BookOpen, FlaskConical, MessageCircleQuestion } from 'lucide-react';

export default function DashboardGreeting() {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Good afternoon, Priya 👋</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          You have <span className="font-semibold text-foreground">3 topics</span> left to complete your Organic Chemistry goal today.
        </p>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <Link
          href="/study-content"
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary text-white text-xs font-semibold hover:opacity-90 active:scale-95 transition-all duration-150"
        >
          <BookOpen size={13} />
          Continue Studying
        </Link>
        <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-warning-soft text-warning text-xs font-semibold hover:bg-warning hover:text-white active:scale-95 transition-all duration-150">
          <FlaskConical size={13} />
          Start a Test
        </button>
        <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-muted text-muted-foreground text-xs font-semibold hover:bg-primary-soft hover:text-primary active:scale-95 transition-all duration-150">
          <MessageCircleQuestion size={13} />
          Ask a Doubt
        </button>
      </div>
    </div>
  );
}