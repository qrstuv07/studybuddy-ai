'use client';
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// BACKEND: fetch /api/study-sessions/weekly-hours for this student

const WEEKLY_DATA = [
  { day: 'Mon', hours: 2.5, target: 3 },
  { day: 'Tue', hours: 3.2, target: 3 },
  { day: 'Wed', hours: 1.8, target: 3 },
  { day: 'Thu', hours: 4.1, target: 3 },
  { day: 'Fri', hours: 0.9, target: 3 },
  { day: 'Sat', hours: 2.0, target: 3 },
  { day: 'Sun', hours: 0, target: 3 },
];

interface TooltipPayloadItem {
  name: string;
  value: number;
  color: string;
}

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: TooltipPayloadItem[]; label?: string }) => {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-card rounded-xl border border-border shadow-card px-3 py-2.5 text-xs">
      <p className="font-semibold text-foreground mb-1.5">{label}</p>
      {payload.map((p, i) => (
        <div key={`tooltip-item-${i}`} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}:</span>
          <span className="font-semibold text-foreground tabular-nums">{p.value}h</span>
        </div>
      ))}
    </div>
  );
};

export default function WeeklyStudyChart() {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-base font-semibold text-foreground">Weekly Study Hours</h3>
          <p className="text-xs text-muted-foreground mt-0.5">This week vs daily target (3 hrs)</p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="w-2.5 h-2.5 rounded-full bg-primary inline-block" />
          Actual
          <span className="w-2.5 h-2.5 rounded-full bg-border inline-block ml-2" />
          Target
        </div>
      </div>
      <ResponsiveContainer width="100%" height={200}>
        <AreaChart data={WEEKLY_DATA} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="gradStudy" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(258,95%,68%)" stopOpacity={0.25} />
              <stop offset="100%" stopColor="hsl(258,95%,68%)" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="gradTarget" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="hsl(240,10%,85%)" stopOpacity={0.3} />
              <stop offset="100%" stopColor="hsl(240,10%,85%)" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="hsl(240,10%,92%)" strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'hsl(240,5%,52%)' }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: 'hsl(240,5%,52%)' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="target"
            name="Target"
            stroke="hsl(240,10%,82%)"
            strokeWidth={1.5}
            strokeDasharray="4 4"
            fill="url(#gradTarget)"
          />
          <Area
            type="monotone"
            dataKey="hours"
            name="Studied"
            stroke="hsl(258,95%,68%)"
            strokeWidth={2.5}
            fill="url(#gradStudy)"
            dot={{ r: 3.5, fill: 'hsl(258,95%,68%)', strokeWidth: 0 }}
            activeDot={{ r: 5, fill: 'hsl(258,95%,68%)', strokeWidth: 2, stroke: '#fff' }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}