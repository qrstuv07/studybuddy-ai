import React from 'react';
import AppLayout from '@/components/AppLayout';
import DashboardGreeting from './components/DashboardGreeting';
import MetricsBentoGrid from './components/MetricsBentoGrid';
import WeeklyStudyChart from './components/WeeklyStudyChart';
import SubjectProgressChart from './components/SubjectProgressChart';
import RecentActivityFeed from './components/RecentActivityFeed';
import RecommendedTopics from './components/RecommendedTopics';
import AIGuidePanel from './components/AIGuidePanel';

export default function HomeDashboardPage() {
  return (
    <AppLayout activeRoute="/home-dashboard">
      <div className="space-y-6 pb-20 lg:pb-6">
        <DashboardGreeting />
        <MetricsBentoGrid />
        <div className="grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2 space-y-5">
            <WeeklyStudyChart />
            <RecommendedTopics />
          </div>
          <div className="xl:col-span-1 space-y-5">
            <AIGuidePanel />
            <SubjectProgressChart />
            <RecentActivityFeed />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}