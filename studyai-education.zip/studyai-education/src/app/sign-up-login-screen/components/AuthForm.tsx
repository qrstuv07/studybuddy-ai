'use client';
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Eye, EyeOff, Loader2, Mail, Lock, User, ArrowRight, CheckCircle2 } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';

interface LoginFormData {
  email: string;
  password: string;
  remember: boolean;
}

interface SignupFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  agreeTerms: boolean;
}

const DEMO_ACCOUNTS = [
  { id: 'demo-student', role: 'Student', email: 'priya.sharma@studyai.app', password: 'StudyAI@2026' },
  { id: 'demo-premium', role: 'Premium Student', email: 'arjun.mehta@studyai.app', password: 'StudyAI@2026' },
];

export default function AuthForm() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const loginForm = useForm<LoginFormData>({
    defaultValues: { email: '', password: '', remember: false },
  });

  const signupForm = useForm<SignupFormData>({
    defaultValues: { name: '', email: '', password: '', confirmPassword: '', agreeTerms: false },
  });

  const handleLoginSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    // BACKEND: POST /api/auth/login with data.email and data.password
    await new Promise((r) => setTimeout(r, 1200));
    const validAccounts = DEMO_ACCOUNTS.map(a => a.email);
    if (!validAccounts.includes(data.email)) {
      loginForm.setError('email', {
        message: 'Invalid credentials — use the demo accounts below to sign in',
      });
      setIsLoading(false);
      return;
    }
    toast.success('Welcome back! Loading your study plan…');
    router.push('/home-dashboard');
    setIsLoading(false);
  };

  const handleSignupSubmit = async (data: SignupFormData) => {
    if (data.password !== data.confirmPassword) {
      signupForm.setError('confirmPassword', { message: 'Passwords do not match' });
      return;
    }
    setIsLoading(true);
    // BACKEND: POST /api/auth/signup with data
    await new Promise((r) => setTimeout(r, 1400));
    toast.success('Account created! Let\'s set up your study profile.');
    router.push('/home-dashboard');
    setIsLoading(false);
  };

  const handleGoogleAuth = async () => {
    setGoogleLoading(true);
    // BACKEND: Initiate Google OAuth flow via /api/auth/google
    await new Promise((r) => setTimeout(r, 1500));
    toast.success('Signed in with Google!');
    router.push('/home-dashboard');
    setGoogleLoading(false);
  };

  const fillDemo = (email: string, password: string) => {
    loginForm.setValue('email', email);
    loginForm.setValue('password', password);
    setMode('login');
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 overflow-y-auto">
      <div className="w-full max-w-[400px]">
        {/* Mobile Logo */}
        <div className="flex items-center gap-2 mb-8 lg:hidden">
          <AppLogo size={30} />
          <span className="font-bold text-lg text-foreground">StudyAI</span>
        </div>

        {/* Header */}
        <div className="mb-7">
          <h2 className="text-2xl font-bold text-foreground mb-1">
            {mode === 'login' ? 'Welcome back 👋' : 'Create your account'}
          </h2>
          <p className="text-sm text-muted-foreground">
            {mode === 'login' ?'Sign in to continue your study session' :'Start studying smarter with your AI guide'}
          </p>
        </div>

        {/* Google Button */}
        <button
          onClick={handleGoogleAuth}
          disabled={googleLoading}
          suppressHydrationWarning
          className="w-full flex items-center justify-center gap-2.5 px-4 py-2.5 rounded-xl border border-border bg-white hover:bg-muted transition-all duration-150 active:scale-95 text-sm font-semibold text-foreground shadow-card disabled:opacity-60 mb-5"
        >
          {googleLoading ? (
            <Loader2 size={16} className="animate-spin text-primary" />
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
          )}
          {googleLoading ? 'Connecting to Google…' : `Continue with Google`}
        </button>

        {/* Divider */}
        <div className="flex items-center gap-3 mb-5">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground font-medium">or {mode === 'login' ? 'sign in' : 'sign up'} with email</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        {/* Login Form */}
        {mode === 'login' && (
          <form onSubmit={loginForm.handleSubmit(handleLoginSubmit)} className="space-y-4 animate-fade-in">
            <div>
              <label className="block text-xs font-semibold text-foreground mb-1.5">Email address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...loginForm.register('email', {
                    required: 'Email is required',
                    pattern: { value: /^\S+@\S+$/i, message: 'Enter a valid email' },
                  })}
                  type="email"
                  placeholder="you@university.edu"
                  suppressHydrationWarning
                  className="input-field pl-9"
                />
              </div>
              {loginForm.formState.errors.email && (
                <p className="mt-1.5 text-xs text-danger">{loginForm.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-foreground">Password</label>
                <button type="button" className="text-xs text-primary hover:underline font-medium">Forgot password?</button>
              </div>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...loginForm.register('password', { required: 'Password is required', minLength: { value: 6, message: 'Minimum 6 characters' } })}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Your password"
                  suppressHydrationWarning
                  className="input-field pl-9 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {loginForm.formState.errors.password && (
                <p className="mt-1.5 text-xs text-danger">{loginForm.formState.errors.password.message}</p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <input
                {...loginForm.register('remember')}
                type="checkbox"
                id="remember-me"
                className="w-4 h-4 rounded border-border accent-primary cursor-pointer"
              />
              <label htmlFor="remember-me" className="text-xs text-muted-foreground cursor-pointer">Remember me for 30 days</label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full flex items-center justify-center gap-2 py-3"
            >
              {isLoading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <>Sign in <ArrowRight size={15} /></>
              )}
            </button>
          </form>
        )}

        {/* Signup Form */}
        {mode === 'signup' && (
          <form onSubmit={signupForm.handleSubmit(handleSignupSubmit)} className="space-y-4 animate-fade-in">
            <div>
              <label className="block text-xs font-semibold text-foreground mb-1.5">Full name</label>
              <div className="relative">
                <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...signupForm.register('name', { required: 'Name is required', minLength: { value: 2, message: 'Enter your full name' } })}
                  type="text"
                  placeholder="Priya Sharma"
                  suppressHydrationWarning
                  className="input-field pl-9"
                />
              </div>
              {signupForm.formState.errors.name && (
                <p className="mt-1.5 text-xs text-danger">{signupForm.formState.errors.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-foreground mb-1.5">Email address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...signupForm.register('email', {
                    required: 'Email is required',
                    pattern: { value: /^\S+@\S+$/i, message: 'Enter a valid email' },
                  })}
                  type="email"
                  placeholder="you@university.edu"
                  suppressHydrationWarning
                  className="input-field pl-9"
                />
              </div>
              {signupForm.formState.errors.email && (
                <p className="mt-1.5 text-xs text-danger">{signupForm.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-foreground mb-1.5">Password</label>
              <p className="text-[11px] text-muted-foreground mb-1.5">At least 8 characters with one number</p>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...signupForm.register('password', {
                    required: 'Password is required',
                    minLength: { value: 8, message: 'Minimum 8 characters' },
                    pattern: { value: /(?=.*[0-9])/, message: 'Must include at least one number' },
                  })}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Create a strong password"
                  suppressHydrationWarning
                  className="input-field pl-9 pr-10"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {signupForm.formState.errors.password && (
                <p className="mt-1.5 text-xs text-danger">{signupForm.formState.errors.password.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-foreground mb-1.5">Confirm password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  {...signupForm.register('confirmPassword', { required: 'Please confirm your password' })}
                  type={showConfirmPass ? 'text' : 'password'}
                  placeholder="Re-enter your password"
                  suppressHydrationWarning
                  className="input-field pl-9 pr-10"
                />
                <button type="button" onClick={() => setShowConfirmPass(!showConfirmPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                  {showConfirmPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {signupForm.formState.errors.confirmPassword && (
                <p className="mt-1.5 text-xs text-danger">{signupForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>

            <div className="flex items-start gap-2">
              <input
                {...signupForm.register('agreeTerms', { required: 'You must agree to the terms' })}
                type="checkbox"
                id="agree-terms"
                className="w-4 h-4 rounded border-border accent-primary cursor-pointer mt-0.5"
              />
              <label htmlFor="agree-terms" className="text-xs text-muted-foreground cursor-pointer leading-relaxed">
                I agree to the{' '}
                <span className="text-primary font-medium hover:underline cursor-pointer">Terms of Service</span>{' '}
                and{' '}
                <span className="text-primary font-medium hover:underline cursor-pointer">Privacy Policy</span>
              </label>
            </div>
            {signupForm.formState.errors.agreeTerms && (
              <p className="text-xs text-danger">{signupForm.formState.errors.agreeTerms.message}</p>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full flex items-center justify-center gap-2 py-3"
            >
              {isLoading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <>Create account <ArrowRight size={15} /></>
              )}
            </button>
          </form>
        )}

        {/* Toggle Mode */}
        <p className="mt-5 text-center text-sm text-muted-foreground">
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
            className="text-primary font-semibold hover:underline"
          >
            {mode === 'login' ? 'Sign up free' : 'Sign in'}
          </button>
        </p>

        {/* Demo Credentials Box */}
        <div className="mt-6 rounded-2xl border border-primary/20 bg-primary-soft/50 p-4">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 size={14} className="text-primary" />
            <p className="text-xs font-semibold text-primary">Demo Accounts — click to autofill</p>
          </div>
          <div className="space-y-2">
            {DEMO_ACCOUNTS.map((acc) => (
              <div key={acc.id} className="flex items-center justify-between gap-3 bg-white rounded-xl px-3 py-2 border border-border">
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-semibold text-foreground">{acc.role}</p>
                  <p className="text-[10px] text-muted-foreground font-mono truncate">{acc.email}</p>
                </div>
                <button
                  type="button"
                  onClick={() => fillDemo(acc.email, acc.password)}
                  className="text-[11px] font-semibold text-primary bg-primary-soft px-2.5 py-1 rounded-lg hover:bg-primary hover:text-white transition-all duration-150 flex-shrink-0"
                >
                  Use
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}