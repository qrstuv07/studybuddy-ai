import React from 'react';
import AppLogo from '@/components/ui/AppLogo';
import { Sparkles, BookOpen, FlaskConical, Languages } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const FEATURES = [
  { id: 'feat-1', icon: Sparkles, label: 'Personal AI Guide', desc: 'Your own AI teacher that knows your pace and gaps' },
  { id: 'feat-2', icon: BookOpen, label: 'Visual Topic Breakdowns', desc: 'Any PDF turned into interactive visual learning cards' },
  { id: 'feat-3', icon: FlaskConical, label: 'Adaptive Self-Tests', desc: 'Tests that get harder as you master each topic' },
  { id: 'feat-4', icon: Languages, label: 'Multi-Language Support', desc: 'Study in your native language with instant translation' },
];

const STATS = [
  { id: 'stat-students', value: '84,200+', label: 'Students' },
  { id: 'stat-topics', value: '2.1M', label: 'Topics Mastered' },
  { id: 'stat-doubts', value: '98.4%', label: 'Doubts Resolved' },
];

export default function AuthBrandPanel() {
  return (
    <div className="hidden lg:flex flex-col w-[52%] xl:w-[55%] bg-gradient-to-br from-[#7C5CFC] via-[#9B7FFB] to-[#C4B0FD] relative overflow-hidden p-10 xl:p-14">
      {/* Background decorative blobs */}
      <div className="absolute top-[-80px] right-[-80px] w-[360px] h-[360px] rounded-full bg-white/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-60px] left-[-60px] w-[280px] h-[280px] rounded-full bg-white/10 blur-3xl pointer-events-none" />
      {/* Logo */}
      <div className="flex items-center gap-2.5 mb-14 relative z-10">
        <AppLogo size={36} />
        <span className="text-white font-bold text-xl tracking-tight">StudyAI</span>
      </div>
      {/* Hero Text */}
      <div className="relative z-10 mb-10">
        <h1 className="text-3xl xl:text-4xl font-bold text-white leading-tight mb-4">
          Your personal AI<br />study companion
        </h1>
        <p className="text-white/80 text-base leading-relaxed max-w-sm">
          Master any subject, solve doubts instantly, and track your progress — all in one place built for college students.
        </p>
      </div>
      {/* Feature List */}
      <div className="relative z-10 space-y-4 mb-12">
        {FEATURES?.map((f) => {
          const Icon = f?.icon;
          return (
            <div key={f?.id} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Icon size={15} className="text-white" />
              </div>
              <div>
                <p className="text-white text-sm font-semibold">{f?.label}</p>
                <p className="text-white/70 text-xs leading-relaxed">{f?.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
      {/* Stats */}
      <div className="relative z-10 flex items-center gap-6 mt-auto">
        {STATS?.map((s) => (
          <div key={s?.id}>
            <p className="text-white font-bold text-xl tabular-nums">{s?.value}</p>
            <p className="text-white/70 text-xs">{s?.label}</p>
          </div>
        ))}
      </div>
      {/* Floating card */}
      <div className="absolute bottom-24 right-10 bg-white/15 backdrop-blur-md rounded-2xl border border-white/25 px-4 py-3 z-10 hidden xl:block">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <p className="text-white text-xs font-semibold">AI Guide is active</p>
        </div>
        <p className="text-white/70 text-xs">"Ready to help you ace Thermodynamics today!"</p>
      </div>
    </div>
  );
}