import React from 'react';
import AppLayout from '@/components/AppLayout';
import StudyContentHeader from './components/StudyContentHeader';
import ChapterSidebar from './components/ChapterSidebar';
import TopicContentArea from './components/TopicContentArea';
import AIDoubtPanel from './components/AIDoubtPanel';

export default function StudyContentPage() {
  return (
    <AppLayout activeRoute="/study-content">
      <div className="space-y-4 pb-20 lg:pb-6">
        <StudyContentHeader />
        <div className="grid grid-cols-1 lg:grid-cols-12 xl:grid-cols-12 2xl:grid-cols-12 gap-5">
          <div className="lg:col-span-3 xl:col-span-3 2xl:col-span-2">
            <ChapterSidebar />
          </div>
          <div className="lg:col-span-6 xl:col-span-6 2xl:col-span-7">
            <TopicContentArea />
          </div>
          <div className="lg:col-span-3 xl:col-span-3 2xl:col-span-3">
            <AIDoubtPanel />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}