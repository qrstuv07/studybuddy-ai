'use client';
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, BookOpen, Zap, CheckCircle2, RotateCcw, FlaskConical, Clock, Trophy } from 'lucide-react';
import TopicMasteryChart from './TopicMasteryChart';
import { toast } from 'sonner';
import Modal from '@/components/ui/Modal';

// BACKEND: fetch /api/topics/:id/content for the active topic

const TOPIC = {
  id: 'tp-3-2',
  title: 'Addition Reactions of Alkenes',
  chapter: 'Chapter 3 — Alkenes & Alkynes',
  subject: 'Organic Chemistry',
  duration: '30 min',
  status: 'in-progress' as const,
  progress: 40,
};

const LEARNING_CARDS = [
  {
    id: 'card-1',
    type: 'concept',
    title: 'What is an Addition Reaction?',
    content: 'In an addition reaction, atoms or groups add across the π bond of an alkene. The double bond (C=C) breaks, and two new sigma bonds form. The alkene acts as a nucleophile attacking electrophilic reagents.',
    formula: 'C=C + X-Y → X-C-C-Y',
    color: 'bg-purple-50 border-purple-100',
    tag: 'Core Concept',
    tagColor: 'bg-purple-100 text-purple-600',
  },
  {
    id: 'card-2',
    type: 'mechanism',
    title: 'Hydrohalogenation (HX Addition)',
    content: 'Markovnikov\'s Rule: In HX addition to an unsymmetrical alkene, H adds to the carbon with more hydrogens, and X adds to the carbon with fewer hydrogens. The more stable carbocation intermediate determines the product.',
    formula: 'CH₂=CH₂ + HBr → CH₃CH₂Br',
    color: 'bg-amber-50 border-amber-100',
    tag: 'Mechanism',
    tagColor: 'bg-amber-100 text-amber-600',
  },
  {
    id: 'card-3',
    type: 'rule',
    title: 'Markovnikov\'s Rule (Memory Aid)',
    content: '"The rich get richer" — the carbon already bearing more hydrogen atoms (more substituted) gains the hydrogen from HX. The halide goes to the carbon with fewer hydrogens, forming the more stable carbocation.',
    formula: 'CH₃-CH=CH₂ + HCl → CH₃-CHCl-CH₃ (major)',
    color: 'bg-green-50 border-green-100',
    tag: 'Memory Rule',
    tagColor: 'bg-green-100 text-green-600',
  },
  {
    id: 'card-4',
    type: 'concept',
    title: 'Hydration (H₂O Addition)',
    content: 'Acid-catalyzed hydration adds water across a double bond. H₂SO₄ acts as a catalyst. The reaction follows Markovnikov\'s rule — OH adds to the more substituted carbon. This is the reverse of dehydration.',
    formula: 'CH₂=CH₂ + H₂O → CH₃CH₂OH (H⁺ catalyst)',
    color: 'bg-blue-50 border-blue-100',
    tag: 'Reaction Type',
    tagColor: 'bg-blue-100 text-blue-600',
  },
  {
    id: 'card-5',
    type: 'application',
    title: 'Halogenation (X₂ Addition)',
    content: 'Addition of Cl₂ or Br₂ to alkenes occurs via a bromonium ion intermediate. This gives anti addition (trans product). The reaction is stereospecific — a cyclic halonium ion intermediate forces anti stereochemistry.',
    formula: 'CH₂=CH₂ + Br₂ → BrCH₂CH₂Br (anti addition)',
    color: 'bg-pink-50 border-pink-100',
    tag: 'Stereo Chemistry',
    tagColor: 'bg-pink-100 text-pink-600',
  },
];

const QUIZ_QUESTIONS = [
  {
    id: 'q-1',
    question: 'What product forms when propene (CH₃CH=CH₂) reacts with HBr?',
    options: [
      { id: 'opt-a', label: '1-bromopropane (CH₃CH₂CH₂Br)' },
      { id: 'opt-b', label: '2-bromopropane (CH₃CHBrCH₃)' },
      { id: 'opt-c', label: 'propan-1-ol' },
      { id: 'opt-d', label: 'propan-2-ol' },
    ],
    correct: 'opt-b',
    explanation: 'By Markovnikov\'s Rule, H adds to C1 (more H atoms) and Br adds to C2 (more substituted), forming 2-bromopropane as the major product.',
  },
  {
    id: 'q-2',
    question: 'Which intermediate forms during halogenation of alkenes?',
    options: [
      { id: 'opt-a', label: 'Carbocation' },
      { id: 'opt-b', label: 'Carbanion' },
      { id: 'opt-c', label: 'Bromonium ion (cyclic halonium)' },
      { id: 'opt-d', label: 'Free radical' },
    ],
    correct: 'opt-c',
    explanation: 'Halogenation proceeds through a cyclic bromonium ion intermediate, which is why the reaction shows anti stereoselectivity.',
  },
];

export default function TopicContentArea() {
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [quizMode, setQuizMode] = useState(false);
  const [quizIndex, setQuizIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [testModalOpen, setTestModalOpen] = useState(false);
  const [topicComplete, setTopicComplete] = useState(false);

  const currentCard = LEARNING_CARDS[cardIndex];
  const currentQ = QUIZ_QUESTIONS[quizIndex];

  const handleNext = () => {
    if (cardIndex < LEARNING_CARDS.length - 1) {
      setCardIndex(cardIndex + 1);
      setFlipped(false);
    }
  };
  const handlePrev = () => {
    if (cardIndex > 0) {
      setCardIndex(cardIndex - 1);
      setFlipped(false);
    }
  };

  const handleAnswerSelect = (optId: string) => {
    if (selectedAnswer) return;
    setSelectedAnswer(optId);
    setShowExplanation(true);
    if (optId === currentQ.correct) {
      toast.success('Correct! Well done 🎉');
    } else {
      toast.error('Not quite — check the explanation below');
    }
  };

  const handleMarkComplete = () => {
    setTopicComplete(true);
    // BACKEND: PATCH /api/topics/:id/status { status: 'mastered' }
    toast.success('Topic marked as mastered! 🏆 +15 XP earned');
  };

  return (
    <div className="space-y-5">
      {/* Topic Header */}
      <div className="card p-5">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="badge bg-primary-soft text-primary">{TOPIC.subject}</span>
              <span className="text-muted-foreground text-xs">/</span>
              <span className="badge bg-muted text-muted-foreground">{TOPIC.chapter}</span>
            </div>
            <h2 className="text-xl font-bold text-foreground">{TOPIC.title}</h2>
            <div className="flex items-center gap-3 mt-2">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock size={12} />
                <span>{TOPIC.duration}</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-warning">
                <Zap size={12} />
                <span>In Progress</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setTestModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-warning-soft text-warning text-xs font-semibold hover:bg-warning hover:text-white active:scale-95 transition-all duration-150"
            >
              <FlaskConical size={13} />
              Quick Quiz
            </button>
            <button
              onClick={handleMarkComplete}
              disabled={topicComplete}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold active:scale-95 transition-all duration-150 ${
                topicComplete
                  ? 'bg-success-soft text-success cursor-default' :'bg-muted text-muted-foreground hover:bg-success-soft hover:text-success'
              }`}
            >
              <CheckCircle2 size={13} />
              {topicComplete ? 'Mastered!' : 'Mark as Mastered'}
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] text-muted-foreground font-medium">Topic Progress</span>
            <span className="text-[11px] font-semibold text-foreground tabular-nums">{TOPIC.progress}%</span>
          </div>
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-r from-primary to-purple-400 transition-all duration-500" style={{ width: `${TOPIC.progress}%` }} />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">{LEARNING_CARDS.length} concepts · {QUIZ_QUESTIONS.length} quiz questions</p>
        </div>
      </div>

      {/* Mode Toggle */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setQuizMode(false)}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${!quizMode ? 'bg-primary text-white' : 'bg-card border border-border text-muted-foreground hover:bg-muted'}`}
        >
          <BookOpen size={13} />
          Learning Cards
        </button>
        <button
          onClick={() => setQuizMode(true)}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${quizMode ? 'bg-primary text-white' : 'bg-card border border-border text-muted-foreground hover:bg-muted'}`}
        >
          <FlaskConical size={13} />
          Quiz Mode
        </button>
      </div>

      {/* Learning Cards */}
      {!quizMode && (
        <div className="space-y-4 animate-fade-in">
          {/* Card Navigation */}
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">Card <span className="font-semibold text-foreground">{cardIndex + 1}</span> of {LEARNING_CARDS.length}</p>
            <div className="flex items-center gap-1.5">
              {LEARNING_CARDS.map((_, i) => (
                <button
                  key={`card-dot-${i}`}
                  onClick={() => { setCardIndex(i); setFlipped(false); }}
                  className={`rounded-full transition-all duration-150 ${i === cardIndex ? 'w-4 h-2 bg-primary' : 'w-2 h-2 bg-muted hover:bg-primary/40'}`}
                />
              ))}
            </div>
          </div>

          {/* Main Learning Card */}
          <div
            className={`card border ${currentCard.color} p-6 min-h-[260px] cursor-pointer transition-all duration-200 hover:shadow-card-hover`}
            onClick={() => setFlipped(!flipped)}
          >
            <div className="flex items-start justify-between mb-3">
              <span className={`badge ${currentCard.tagColor} text-[10px] font-semibold`}>{currentCard.tag}</span>
              <button onClick={(e) => { e.stopPropagation(); setFlipped(!flipped); }} className="text-[10px] text-muted-foreground flex items-center gap-1 hover:text-foreground transition-colors">
                <RotateCcw size={11} />
                {flipped ? 'Show content' : 'Show formula'}
              </button>
            </div>

            {!flipped ? (
              <div className="animate-fade-in">
                <h3 className="text-base font-bold text-foreground mb-3">{currentCard.title}</h3>
                <p className="text-sm text-foreground leading-relaxed">{currentCard.content}</p>
              </div>
            ) : (
              <div className="animate-fade-in flex flex-col items-center justify-center h-36">
                <p className="text-xs text-muted-foreground mb-3 font-medium uppercase tracking-widest">Key Formula / Reaction</p>
                <div className="bg-white/80 rounded-2xl border border-border px-6 py-4 text-center">
                  <p className="font-mono text-sm font-semibold text-foreground leading-relaxed">{currentCard.formula}</p>
                </div>
              </div>
            )}
          </div>

          {/* Card Nav Buttons */}
          <div className="flex items-center justify-between">
            <button
              onClick={handlePrev}
              disabled={cardIndex === 0}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-border bg-card text-sm font-medium text-foreground hover:bg-muted active:scale-95 transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft size={15} /> Previous
            </button>
            <p className="text-xs text-muted-foreground">Tap card to reveal formula</p>
            <button
              onClick={handleNext}
              disabled={cardIndex === LEARNING_CARDS.length - 1}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-white text-sm font-medium hover:opacity-90 active:scale-95 transition-all duration-150 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Next <ChevronRight size={15} />
            </button>
          </div>

          {/* All Cards Overview */}
          <div className="card p-4">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-3">All Concepts in This Topic</p>
            <div className="space-y-2">
              {LEARNING_CARDS.map((c, i) => (
                <button
                  key={c.id}
                  onClick={() => { setCardIndex(i); setFlipped(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition-all duration-150 hover:border-primary/30 hover:bg-primary-soft/20 text-left ${i === cardIndex ? 'border-primary/40 bg-primary-soft/30' : 'border-border bg-transparent'}`}
                >
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 text-[10px] font-bold ${i === cardIndex ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-foreground truncate">{c.title}</p>
                    <span className={`badge text-[10px] mt-0.5 ${c.tagColor}`}>{c.tag}</span>
                  </div>
                  {i < cardIndex && <CheckCircle2 size={13} className="text-success flex-shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Quiz Mode */}
      {quizMode && (
        <div className="space-y-4 animate-fade-in">
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs text-muted-foreground font-medium">Question <span className="font-bold text-foreground">{quizIndex + 1}</span> of {QUIZ_QUESTIONS.length}</p>
              <span className="badge bg-warning-soft text-warning">Quick Quiz</span>
            </div>
            <p className="text-sm font-semibold text-foreground leading-relaxed mb-4">{currentQ.question}</p>
            <div className="space-y-2">
              {currentQ.options.map((opt) => {
                const isSelected = selectedAnswer === opt.id;
                const isCorrect = opt.id === currentQ.correct;
                let optClass = 'border-border bg-white hover:border-primary/40 hover:bg-primary-soft/20';
                if (selectedAnswer) {
                  if (isCorrect) optClass = 'border-success bg-success-soft text-success';
                  else if (isSelected && !isCorrect) optClass = 'border-danger bg-danger-soft text-danger';
                  else optClass = 'border-border bg-white opacity-60';
                }
                return (
                  <button
                    key={opt.id}
                    onClick={() => handleAnswerSelect(opt.id)}
                    disabled={!!selectedAnswer}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-all duration-150 ${optClass}`}
                  >
                    <span className="w-5 h-5 rounded-full border-2 border-current flex items-center justify-center flex-shrink-0 text-[10px] font-bold">
                      {opt.id.split('-')[1].toUpperCase()}
                    </span>
                    <span className="text-sm">{opt.label}</span>
                    {selectedAnswer && isCorrect && <CheckCircle2 size={14} className="ml-auto text-success" />}
                  </button>
                );
              })}
            </div>
            {showExplanation && (
              <div className="mt-4 p-3 rounded-xl bg-primary-soft/50 border border-primary/20 animate-slide-up">
                <p className="text-xs font-semibold text-primary mb-1">Explanation</p>
                <p className="text-xs text-foreground leading-relaxed">{currentQ.explanation}</p>
              </div>
            )}
            {selectedAnswer && quizIndex < QUIZ_QUESTIONS.length - 1 && (
              <button
                onClick={() => { setQuizIndex(quizIndex + 1); setSelectedAnswer(null); setShowExplanation(false); }}
                className="btn-primary mt-4 w-full flex items-center justify-center gap-2"
              >
                Next Question <ChevronRight size={15} />
              </button>
            )}
            {selectedAnswer && quizIndex === QUIZ_QUESTIONS.length - 1 && (
              <div className="mt-4 p-3 rounded-xl bg-success-soft border border-success/20 flex items-center gap-3 animate-slide-up">
                <Trophy size={18} className="text-success flex-shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-success">Quiz Complete!</p>
                  <p className="text-[11px] text-muted-foreground">Great work on this topic. Review the cards to reinforce your learning.</p>
                </div>
                <button onClick={() => { setQuizMode(false); setQuizIndex(0); setSelectedAnswer(null); setShowExplanation(false); }} className="ml-auto text-xs font-semibold text-primary hover:underline flex-shrink-0">
                  Back to Cards
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Topic Mastery Chart */}
      <TopicMasteryChart />

      {/* Test Launch Modal */}
      <Modal open={testModalOpen} onClose={() => setTestModalOpen(false)} title="Start Chapter Test" size="md">
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">Configure your test for <span className="font-semibold text-foreground">Addition Reactions of Alkenes</span>.</p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: 'test-opt-1', label: '5 Questions', sub: '~8 minutes', recommended: false },
              { id: 'test-opt-2', label: '10 Questions', sub: '~15 minutes', recommended: true },
              { id: 'test-opt-3', label: '20 Questions', sub: '~30 minutes', recommended: false },
              { id: 'test-opt-4', label: 'Full Chapter', sub: '~45 minutes', recommended: false },
            ].map((opt) => (
              <button
                key={opt.id}
                onClick={() => { setTestModalOpen(false); toast.success(`Test started: ${opt.label}`); }}
                className={`flex flex-col items-start gap-1 p-3.5 rounded-2xl border transition-all duration-150 hover:border-primary/40 hover:bg-primary-soft/20 active:scale-95 ${opt.recommended ? 'border-primary/40 bg-primary-soft/30' : 'border-border bg-white'}`}
              >
                <div className="flex items-center gap-2 w-full">
                  <span className="text-sm font-semibold text-foreground">{opt.label}</span>
                  {opt.recommended && <span className="badge bg-primary-soft text-primary ml-auto">Recommended</span>}
                </div>
                <span className="text-xs text-muted-foreground">{opt.sub}</span>
              </button>
            ))}
          </div>
          <div className="p-3 rounded-xl bg-muted/60 border border-border">
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              <span className="font-semibold text-foreground">AI-Adaptive:</span> Questions adjust based on your previous performance. Wrong answers will appear more frequently until mastered.
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
}