'use client';
import React, { useState } from 'react';
import { ChevronDown, ChevronRight, CheckCircle2, Circle, Clock, Loader } from 'lucide-react';

// BACKEND: fetch /api/subjects/:id/chapters for the selected subject

interface Topic {
  id: string;
  label: string;
  status: 'mastered' | 'in-progress' | 'not-started';
  duration: string;
}

interface Chapter {
  id: string;
  label: string;
  topics: Topic[];
  completion: number;
}

const CHAPTERS: Chapter[] = [
  {
    id: 'ch-1',
    label: 'Ch. 1 — Introduction to Organic Chemistry',
    completion: 100,
    topics: [
      { id: 'tp-1-1', label: 'Carbon Bonding & Hybridization', status: 'mastered', duration: '18 min' },
      { id: 'tp-1-2', label: 'Functional Groups Overview', status: 'mastered', duration: '22 min' },
      { id: 'tp-1-3', label: 'IUPAC Nomenclature Basics', status: 'mastered', duration: '15 min' },
    ],
  },
  {
    id: 'ch-2',
    label: 'Ch. 2 — Stereochemistry',
    completion: 67,
    topics: [
      { id: 'tp-2-1', label: 'Chirality & Enantiomers', status: 'mastered', duration: '20 min' },
      { id: 'tp-2-2', label: 'R/S Configuration', status: 'mastered', duration: '25 min' },
      { id: 'tp-2-3', label: 'Diastereomers & Meso Compounds', status: 'not-started', duration: '28 min' },
    ],
  },
  {
    id: 'ch-3',
    label: 'Ch. 3 — Alkenes & Alkynes',
    completion: 33,
    topics: [
      { id: 'tp-3-1', label: 'Structure & Naming of Alkenes', status: 'mastered', duration: '16 min' },
      { id: 'tp-3-2', label: 'Addition Reactions', status: 'in-progress', duration: '30 min' },
      { id: 'tp-3-3', label: 'Alkynes: Reactions & Synthesis', status: 'not-started', duration: '24 min' },
    ],
  },
  {
    id: 'ch-4',
    label: 'Ch. 4 — Aromatic Compounds',
    completion: 0,
    topics: [
      { id: 'tp-4-1', label: 'Benzene & Aromaticity (Hückel\'s Rule)', status: 'not-started', duration: '22 min' },
      { id: 'tp-4-2', label: 'Electrophilic Aromatic Substitution', status: 'not-started', duration: '35 min' },
      { id: 'tp-4-3', label: 'Directing Groups & Effects', status: 'not-started', duration: '28 min' },
    ],
  },
  {
    id: 'ch-5',
    label: 'Ch. 5 — Reaction Mechanisms',
    completion: 0,
    topics: [
      { id: 'tp-5-1', label: 'Nucleophilic Substitution (SN1 & SN2)', status: 'not-started', duration: '25 min' },
      { id: 'tp-5-2', label: 'Elimination Reactions (E1 & E2)', status: 'not-started', duration: '22 min' },
      { id: 'tp-5-3', label: 'Aldol Condensation', status: 'not-started', duration: '20 min' },
    ],
  },
];

const STATUS_ICON = {
  mastered: <CheckCircle2 size={13} className="text-success flex-shrink-0" />,
  'in-progress': <Loader size={13} className="text-warning flex-shrink-0 animate-spin" />,
  'not-started': <Circle size={13} className="text-muted-foreground flex-shrink-0" />,
};

export default function ChapterSidebar() {
  const [openChapters, setOpenChapters] = useState<string[]>(['ch-3']);
  const [activeTopicId, setActiveTopicId] = useState('tp-3-2');

  const toggleChapter = (id: string) => {
    setOpenChapters((prev) => prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]);
  };

  return (
    <div className="card p-0 overflow-hidden sticky top-0">
      <div className="px-4 py-3.5 border-b border-border bg-muted/40">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Chapters</p>
        <p className="text-sm font-semibold text-foreground mt-0.5">Organic Chemistry</p>
      </div>
      <div className="overflow-y-auto scrollbar-thin" style={{ maxHeight: 'calc(100vh - 220px)' }}>
        {CHAPTERS.map((ch) => {
          const isOpen = openChapters.includes(ch.id);
          return (
            <div key={ch.id} className="border-b border-border last:border-0">
              <button
                onClick={() => toggleChapter(ch.id)}
                className="w-full flex items-center gap-2 px-4 py-3 hover:bg-muted/50 transition-colors text-left group"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-foreground leading-snug">{ch.label}</p>
                  <div className="flex items-center gap-1.5 mt-1">
                    <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${ch.completion === 100 ? 'bg-success' : ch.completion > 0 ? 'bg-primary' : 'bg-muted'}`}
                        style={{ width: `${ch.completion}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-muted-foreground tabular-nums flex-shrink-0">{ch.completion}%</span>
                  </div>
                </div>
                {isOpen ? (
                  <ChevronDown size={13} className="text-muted-foreground flex-shrink-0" />
                ) : (
                  <ChevronRight size={13} className="text-muted-foreground flex-shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="pb-1 animate-fade-in">
                  {ch.topics.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setActiveTopicId(t.id)}
                      className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-left transition-colors hover:bg-muted/50 ${
                        activeTopicId === t.id ? 'bg-primary-soft/60 border-r-2 border-primary' : ''
                      }`}
                    >
                      {STATUS_ICON[t.status]}
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs leading-snug ${activeTopicId === t.id ? 'font-semibold text-primary' : 'text-foreground'}`}>
                          {t.label}
                        </p>
                        <div className="flex items-center gap-1 mt-0.5">
                          <Clock size={9} className="text-muted-foreground" />
                          <span className="text-[10px] text-muted-foreground">{t.duration}</span>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}