'use client';
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

// BACKEND: fetch /api/subjects/:id/topic-scores for the student

const TOPIC_SCORES = [
  { id: 'ts-1', topic: 'Carbon Bonding', score: 92, attempts: 3 },
  { id: 'ts-2', topic: 'Functional Groups', score: 88, attempts: 2 },
  { id: 'ts-3', topic: 'IUPAC Names', score: 95, attempts: 4 },
  { id: 'ts-4', topic: 'Chirality', score: 74, attempts: 3 },
  { id: 'ts-5', topic: 'R/S Config', score: 68, attempts: 5 },
  { id: 'ts-6', topic: 'Diastereomers', score: 0, attempts: 0 },
  { id: 'ts-7', topic: 'Alkene Structure', score: 82, attempts: 2 },
  { id: 'ts-8', topic: 'Addition Rxns', score: 58, attempts: 2 },
];

const getBarColor = (score: number) => {
  if (score === 0) return 'hsl(240,10%,88%)';
  if (score >= 85) return 'hsl(142,71%,45%)';
  if (score >= 70) return 'hsl(258,95%,68%)';
  return 'hsl(0,84%,60%)';
};

interface TooltipPayloadItem {
  payload: { topic: string; score: number; attempts: number };
}

const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: TooltipPayloadItem[] }) => {
  if (!active || !payload || payload.length === 0) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-card rounded-xl border border-border shadow-card px-3 py-2.5 text-xs">
      <p className="font-semibold text-foreground mb-1">{d.topic}</p>
      <p className="text-muted-foreground">Score: <span className="font-semibold text-foreground tabular-nums">{d.score > 0 ? `${d.score}%` : 'Not attempted'}</span></p>
      {d.attempts > 0 && <p className="text-muted-foreground">Attempts: <span className="font-semibold text-foreground">{d.attempts}</span></p>}
    </div>
  );
};

export default function TopicMasteryChart() {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold text-foreground">Topic Mastery Scores</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Organic Chemistry — test performance by topic</p>
        </div>
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-success inline-block" /> Mastered (≥85%)</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-primary inline-block" /> Good (70–84%)</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-danger inline-block" /> Needs Work</span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={TOPIC_SCORES} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <CartesianGrid stroke="hsl(240,10%,92%)" strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="topic"
            tick={{ fontSize: 10, fill: 'hsl(240,5%,52%)' }}
            axisLine={false}
            tickLine={false}
            interval={0}
            angle={-25}
            textAnchor="end"
            height={40}
          />
          <YAxis
            tick={{ fontSize: 10, fill: 'hsl(240,5%,52%)' }}
            axisLine={false}
            tickLine={false}
            domain={[0, 100]}
            tickFormatter={(v) => `${v}%`}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'hsl(258,95%,68%,0.05)' }} />
          <Bar dataKey="score" radius={[5, 5, 0, 0]} maxBarSize={32}>
            {TOPIC_SCORES.map((entry) => (
              <Cell key={`cell-${entry.id}`} fill={getBarColor(entry.score)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}