'use client';
import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Loader2, BookOpen, Lightbulb, MessageCircleQuestion, ChevronDown, ChevronUp, Paperclip } from 'lucide-react';
import { toast } from 'sonner';

// BACKEND: POST /api/ai/doubt-solve with { question, topicId, subjectId } → AI answer

interface DoubtMessage {
  id: string;
  role: 'ai' | 'user';
  text: string;
  type?: 'doubt' | 'explanation' | 'example';
}

const SUGGESTED_DOUBTS = [
  { id: 'sd-1', text: 'Why does Markovnikov\'s rule work?' },
  { id: 'sd-2', text: 'What\'s the difference between syn and anti addition?' },
  { id: 'sd-3', text: 'How do I identify the major product?' },
  { id: 'sd-4', text: 'Explain bromonium ion with a diagram' },
];

const AI_RESPONSES: Record<string, string> = {
  "Why does Markovnikov's rule work?": "Markovnikov's rule works because of carbocation stability! 🧪\n\nWhen HX adds to an alkene:\n1. H⁺ adds first, creating a carbocation\n2. More substituted carbons form MORE STABLE carbocations (3° > 2° > 1°)\n3. The stable carbocation forms preferentially\n4. X⁻ then attacks this stable intermediate\n\nSo the rule is really about which carbocation is more stable, not just counting H atoms! The methyl groups donate electron density through hyperconjugation, stabilizing the positive charge.",
  "What's the difference between syn and anti addition?": "Great question! 🔬\n\nSYN Addition: Both groups add to the SAME face of the double bond\n• Example: Hydroboration-oxidation (BH₃ then H₂O₂)\n• Result: cis/syn product\n\nANTI Addition: Groups add to OPPOSITE faces\n• Example: Halogenation with Br₂ (via bromonium ion)\n• Result: trans/anti product\n\nMemory trick: 'Bromine is anti-social' → anti addition! The cyclic bromonium ion physically blocks approach from the same face.",
  "How do I identify the major product?": "Step-by-step approach: 📋\n\n1. Identify the reaction type (HX, H₂O, X₂, etc.)\n2. Check if the alkene is symmetrical or unsymmetrical\n3. For HX/H₂O: Apply Markovnikov's rule → H goes to more H-bearing carbon\n4. For X₂: Anti addition → trans product\n5. Consider carbocation stability if rearrangement is possible\n6. Check for special reagents (anti-Markovnikov if peroxides present with HBr)\n\nAlways draw the mechanism — it shows you exactly which product forms!",
  "Explain bromonium ion with a diagram": "The bromonium ion mechanism: 🔄\n\nStep 1: Br₂ approaches the alkene π bond\nStep 2: One Br becomes electrophilic (δ+) and attacks the π electrons\nStep 3: A 3-membered CYCLIC bromonium ion forms (Br bridges both carbons)\nStep 4: Br⁻ (nucleophile) attacks from the BACK side — anti to the bromonium\nStep 5: This backside attack gives the anti addition product\n\nThe cyclic bridge physically BLOCKS syn attack, guaranteeing the anti stereochemistry. This is why halogenation is stereospecific!",
};

const INITIAL_MESSAGES: DoubtMessage[] = [
  {
    id: 'init-1',
    role: 'ai',
    text: "Hi! I'm your AI Doubt Solver for this topic 🤖\n\nAsk me anything about Addition Reactions — I can explain concepts, work through problems, or give you examples. What's confusing you?",
    type: 'explanation',
  },
];

export default function AIDoubtPanel() {
  const [messages, setMessages] = useState<DoubtMessage[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [resolvedCount, setResolvedCount] = useState(3);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    const userMsg: DoubtMessage = { id: `doubt-user-${Date.now()}`, role: 'user', text };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    // BACKEND: POST /api/ai/doubt-solve
    await new Promise((r) => setTimeout(r, 1400));
    const reply = AI_RESPONSES[text] || `That's a thoughtful question about "${text}"! 💡\n\nBased on the Addition Reactions topic, here's what I can tell you:\n\nThe key principle to understand is that alkenes are nucleophiles — they attack electrophilic reagents. The π electrons (the loosely held electrons in the double bond) are what make alkenes reactive.\n\nFor your specific question, I'd recommend reviewing the mechanism step by step and identifying which bond breaks and which forms. Would you like me to walk through a specific example to clarify this?`;
    setMessages((prev) => [...prev, { id: `doubt-ai-${Date.now()}`, role: 'ai', text: reply, type: 'explanation' }]);
    setResolvedCount((c) => c + 1);
    setLoading(false);
    toast.success('Doubt resolved! +1 to your solved count');
  };

  return (
    <div className="space-y-4">
      {/* Doubt Solver Card */}
      <div className="card overflow-hidden">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-between px-5 py-4 hover:bg-muted/40 transition-colors"
        >
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-primary to-purple-400 flex items-center justify-center">
              <MessageCircleQuestion size={14} className="text-white" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-foreground">AI Doubt Solver</p>
              <p className="text-[10px] text-muted-foreground">{resolvedCount} doubts resolved this session</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="badge bg-success-soft text-success text-[10px]">Active</span>
            {collapsed ? <ChevronDown size={15} className="text-muted-foreground" /> : <ChevronUp size={15} className="text-muted-foreground" />}
          </div>
        </button>

        {!collapsed && (
          <div className="animate-slide-up">
            {/* Messages */}
            <div className="px-4 pb-3 space-y-3 overflow-y-auto scrollbar-thin" style={{ maxHeight: '320px' }}>
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {m.role === 'ai' && (
                    <div className="w-5 h-5 rounded-full bg-primary-soft flex items-center justify-center flex-shrink-0 mr-1.5 mt-0.5">
                      <Sparkles size={10} className="text-primary" />
                    </div>
                  )}
                  <div
                    className={`max-w-[90%] rounded-2xl px-3 py-2.5 text-xs leading-relaxed whitespace-pre-line ${
                      m.role === 'ai' ?'bg-muted/60 text-foreground rounded-tl-sm' :'bg-primary text-white rounded-tr-sm'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start items-center gap-1.5">
                  <div className="w-5 h-5 rounded-full bg-primary-soft flex items-center justify-center flex-shrink-0">
                    <Sparkles size={10} className="text-primary" />
                  </div>
                  <div className="bg-muted/60 rounded-2xl rounded-tl-sm px-3 py-2 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Doubts */}
            <div className="px-4 pb-3">
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest mb-2">Common doubts</p>
              <div className="space-y-1.5">
                {SUGGESTED_DOUBTS.map((sd) => (
                  <button
                    key={sd.id}
                    onClick={() => handleSend(sd.text)}
                    disabled={loading}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl bg-muted/50 hover:bg-primary-soft/50 hover:text-primary transition-all duration-150 text-left group disabled:opacity-50"
                  >
                    <Lightbulb size={11} className="text-muted-foreground group-hover:text-primary flex-shrink-0 transition-colors" />
                    <span className="text-[11px] text-muted-foreground group-hover:text-primary transition-colors">{sd.text}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="px-4 pb-4">
              <div className="flex items-center gap-2 bg-muted/40 rounded-2xl border border-border px-3 py-2">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(input); }}}
                  placeholder="Type your doubt here…"
                  className="flex-1 bg-transparent text-xs text-foreground placeholder:text-muted-foreground outline-none"
                  disabled={loading}
                />
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => toast.info('Attach an image of your notes or textbook page')}
                    className="w-6 h-6 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <Paperclip size={13} />
                  </button>
                  <button
                    onClick={() => handleSend(input)}
                    disabled={loading || !input.trim()}
                    className="w-7 h-7 rounded-xl bg-primary flex items-center justify-center text-white hover:opacity-90 active:scale-95 transition-all duration-150 disabled:opacity-50"
                  >
                    {loading ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Study Stats Card */}
      <div className="card p-4 space-y-3">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">This Topic</p>
        {[
          { id: 'ts-time', label: 'Time Spent', value: '12 min', sub: 'of 30 min estimated' },
          { id: 'ts-cards', label: 'Cards Reviewed', value: '3 / 5', sub: '60% of topic' },
          { id: 'ts-quiz', label: 'Quiz Accuracy', value: '1 / 1', sub: '100% so far' },
          { id: 'ts-doubts', label: 'Doubts Asked', value: `${resolvedCount}`, sub: 'all resolved by AI' },
        ].map((s) => (
          <div key={s.id} className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-foreground">{s.label}</p>
              <p className="text-[10px] text-muted-foreground">{s.sub}</p>
            </div>
            <span className="text-sm font-bold text-foreground tabular-nums">{s.value}</span>
          </div>
        ))}
      </div>

      {/* Related Topics */}
      <div className="card p-4">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen size={14} className="text-primary" />
          <p className="text-xs font-semibold text-foreground">Related Topics</p>
        </div>
        <div className="space-y-1.5">
          {[
            { id: 'rt-1', label: 'Elimination Reactions (E1 & E2)', chapter: 'Ch. 5', status: 'not-started' },
            { id: 'rt-2', label: 'Carbocation Stability', chapter: 'Ch. 3', status: 'mastered' },
            { id: 'rt-3', label: 'Stereochemistry of Reactions', chapter: 'Ch. 2', status: 'in-progress' },
          ].map((rt) => (
            <button
              key={rt.id}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-muted/50 transition-colors text-left group"
            >
              <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${rt.status === 'mastered' ? 'bg-success' : rt.status === 'in-progress' ? 'bg-warning' : 'bg-muted-foreground'}`} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground group-hover:text-primary transition-colors truncate">{rt.label}</p>
                <p className="text-[10px] text-muted-foreground">{rt.chapter}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}