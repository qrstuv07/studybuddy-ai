'use client';
import React, { useState } from 'react';
import { BookOpen, ChevronDown, Languages, FlaskConical, Upload } from 'lucide-react';
import { toast } from 'sonner';

const SUBJECTS = [
  { id: 'subj-chem', label: 'Organic Chemistry', progress: 62 },
  { id: 'subj-math', label: 'Calculus', progress: 45 },
  { id: 'subj-physics', label: 'Thermodynamics', progress: 78 },
  { id: 'subj-cs', label: 'Data Structures', progress: 33 },
  { id: 'subj-bio', label: 'Cell Biology', progress: 20 },
];

const LANGUAGES = [
  { id: 'lang-en', code: 'EN', label: 'English' },
  { id: 'lang-hi', code: 'HI', label: 'Hindi' },
  { id: 'lang-es', code: 'ES', label: 'Español' },
  { id: 'lang-fr', code: 'FR', label: 'Français' },
  { id: 'lang-de', code: 'DE', label: 'Deutsch' },
];

export default function StudyContentHeader() {
  const [subjectOpen, setSubjectOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState(SUBJECTS?.[0]);
  const [selectedLang, setSelectedLang] = useState(LANGUAGES?.[0]);

  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div className="flex items-center gap-3 flex-wrap">
        {/* Subject Selector */}
        <div className="relative">
          <button
            onClick={() => { setSubjectOpen(!subjectOpen); setLangOpen(false); }}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-card border border-border hover:border-primary/40 hover:bg-primary-soft/30 transition-all duration-150 text-sm font-semibold text-foreground"
          >
            <BookOpen size={15} className="text-primary" />
            {selectedSubject?.label}
            <div className="flex items-center gap-1 ml-1">
              <div className="w-12 h-1.5 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-primary" style={{ width: `${selectedSubject?.progress}%` }} />
              </div>
              <span className="text-[10px] text-muted-foreground tabular-nums">{selectedSubject?.progress}%</span>
            </div>
            <ChevronDown size={13} className="text-muted-foreground" />
          </button>
          {subjectOpen && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setSubjectOpen(false)} />
              <div className="absolute top-full left-0 mt-1 w-64 bg-card rounded-2xl border border-border shadow-modal overflow-hidden animate-slide-up z-40">
                {SUBJECTS?.map((s) => (
                  <button
                    key={s?.id}
                    onClick={() => { setSelectedSubject(s); setSubjectOpen(false); }}
                    className={`w-full flex items-center justify-between px-4 py-2.5 hover:bg-muted transition-colors text-sm ${selectedSubject?.id === s?.id ? 'bg-primary-soft text-primary font-semibold' : 'text-foreground'}`}
                  >
                    <span>{s?.label}</span>
                    <div className="flex items-center gap-1.5">
                      <div className="w-14 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full bg-primary" style={{ width: `${s?.progress}%` }} />
                      </div>
                      <span className="text-[11px] text-muted-foreground tabular-nums">{s?.progress}%</span>
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Language Toggle */}
        <div className="relative">
          <button
            onClick={() => { setLangOpen(!langOpen); setSubjectOpen(false); }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-card border border-border hover:border-primary/40 transition-all duration-150 text-sm font-semibold text-foreground"
          >
            <Languages size={15} className="text-muted-foreground" />
            {selectedLang?.code}
            <ChevronDown size={13} className="text-muted-foreground" />
          </button>
          {langOpen && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setLangOpen(false)} />
              <div className="absolute top-full left-0 mt-1 w-36 bg-card rounded-2xl border border-border shadow-modal overflow-hidden animate-slide-up z-40">
                {LANGUAGES?.map((l) => (
                  <button
                    key={l?.id}
                    onClick={() => {
                      setSelectedLang(l);
                      setLangOpen(false);
                      toast?.success(`Content language set to ${l?.label}`);
                    }}
                    className={`w-full flex items-center gap-2 px-4 py-2.5 hover:bg-muted transition-colors text-sm ${selectedLang?.id === l?.id ? 'bg-primary-soft text-primary font-semibold' : 'text-foreground'}`}
                  >
                    <span className="font-mono text-[11px] font-semibold text-muted-foreground">{l?.code}</span>
                    <span>{l?.label}</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => toast?.info('PDF upload — drag & drop your lecture slides or textbook PDF')}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-dashed border-primary/40 text-primary text-xs font-semibold hover:bg-primary-soft transition-all duration-150"
        >
          <Upload size={13} />
          Upload PDF
        </button>
        <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-warning-soft text-warning text-xs font-semibold hover:bg-warning hover:text-white active:scale-95 transition-all duration-150">
          <FlaskConical size={13} />
          Start Chapter Test
        </button>
      </div>
    </div>
  );
}