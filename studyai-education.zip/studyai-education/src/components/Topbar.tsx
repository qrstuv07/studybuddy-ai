'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { Search, Bell, Sparkles, X, BookOpen } from 'lucide-react';

const QUICK_RESULTS = [
  { id: 'qr-1', label: 'Thermodynamics — Chapter 3', type: 'topic', route: '/study-content' },
  { id: 'qr-2', label: 'Organic Chemistry: Alkenes', type: 'topic', route: '/study-content' },
  { id: 'qr-3', label: 'Calculus — Integration by Parts', type: 'topic', route: '/study-content' },
  { id: 'qr-4', label: 'Data Structures: Binary Trees', type: 'topic', route: '/study-content' },
];

const NOTIFICATIONS = [
  { id: 'notif-1', text: 'Your test "Organic Chemistry Ch.4" is ready', time: '5m ago', unread: true },
  { id: 'notif-2', text: 'AI Guide answered your doubt on Integration', time: '1h ago', unread: true },
  { id: 'notif-3', text: 'Study streak: 12 days! Keep it up 🔥', time: '3h ago', unread: false },
  { id: 'notif-4', text: 'New topic added: Linear Algebra Chapter 5', time: 'Yesterday', unread: false },
];

export default function Topbar() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchVal, setSearchVal] = useState('');
  const [notifOpen, setNotifOpen] = useState(false);

  return (
    <header className="h-14 border-b border-border bg-card flex items-center px-4 lg:px-6 gap-3 flex-shrink-0 relative z-40">
      {/* Mobile Logo */}
      <div className="lg:hidden flex items-center gap-2 mr-2">
        <AppLogo size={28} />
        <span className="font-semibold text-sm text-foreground">StudyAI</span>
      </div>
      {/* Search Bar */}
      <div className="flex-1 max-w-md relative">
        {searchOpen ? (
          <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2 animate-scale-in">
            <Search size={15} className="text-muted-foreground flex-shrink-0" />
            <input
              autoFocus
              value={searchVal}
              onChange={(e) => setSearchVal(e?.target?.value)}
              placeholder="Search topics, chapters, doubts..."
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            <button onClick={() => { setSearchOpen(false); setSearchVal(''); }}>
              <X size={15} className="text-muted-foreground hover:text-foreground transition-colors" />
            </button>
            {searchVal?.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-card rounded-2xl border border-border shadow-modal overflow-hidden animate-slide-up">
                {QUICK_RESULTS?.map((r) => (
                  <Link
                    key={r?.id}
                    href={r?.route}
                    onClick={() => setSearchOpen(false)}
                    className="flex items-center gap-3 px-4 py-2.5 hover:bg-muted transition-colors"
                  >
                    <BookOpen size={14} className="text-primary flex-shrink-0" />
                    <span className="text-sm text-foreground">{r?.label}</span>
                    <span className="ml-auto badge bg-primary-soft text-primary">{r?.type}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        ) : (
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm px-3 py-2 rounded-xl hover:bg-muted transition-all duration-150"
          >
            <Search size={15} />
            <span className="hidden sm:block">Search topics, chapters…</span>
            <kbd className="hidden sm:block ml-2 px-1.5 py-0.5 text-[10px] font-mono bg-muted rounded border border-border">⌘K</kbd>
          </button>
        )}
      </div>
      <div className="flex items-center gap-1 ml-auto">
        {/* AI Guide Quick Access */}
        <Link
          href="/home-dashboard"
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary-soft text-primary text-xs font-semibold hover:bg-primary hover:text-white transition-all duration-150"
        >
          <Sparkles size={13} />
          Ask AI
        </Link>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative w-9 h-9 flex items-center justify-center rounded-xl hover:bg-muted transition-colors"
          >
            <Bell size={18} className="text-muted-foreground" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-primary" />
          </button>
          {notifOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-80 bg-card rounded-2xl border border-border shadow-modal overflow-hidden animate-slide-up z-50">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                  <p className="text-sm font-semibold text-foreground">Notifications</p>
                  <span className="badge bg-primary-soft text-primary">2 new</span>
                </div>
                {NOTIFICATIONS?.map((n) => (
                  <div key={n?.id} className={`flex items-start gap-3 px-4 py-3 hover:bg-muted transition-colors cursor-pointer border-b border-border last:border-0 ${n?.unread ? 'bg-primary-soft/30' : ''}`}>
                    <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n?.unread ? 'bg-primary' : 'bg-transparent'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-foreground leading-relaxed">{n?.text}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">{n?.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Avatar */}
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-purple-400 flex items-center justify-center text-white text-xs font-bold cursor-pointer ml-1">
          PS
        </div>
      </div>
    </header>
  );
}