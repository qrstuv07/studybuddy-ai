import React from 'react';

type BadgeVariant = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'muted' | 'amber';

interface BadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  className?: string;
}

const VARIANT_CLASSES: Record<BadgeVariant, string> = {
  primary: 'bg-primary-soft text-primary',
  success: 'bg-success-soft text-success',
  warning: 'bg-warning-soft text-warning',
  danger: 'bg-danger-soft text-danger',
  info: 'bg-info-soft text-info',
  muted: 'bg-muted text-muted-foreground',
  amber: 'bg-amber-50 text-amber-600',
};

export default function Badge({ variant = 'muted', children, className = '' }: BadgeProps) {
  return (
    <span className={`badge ${VARIANT_CLASSES[variant]} ${className}`}>
      {children}
    </span>
  );
}