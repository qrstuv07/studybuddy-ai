'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';
import { LayoutDashboard, BookOpen, FlaskConical, MessageCircleQuestion, Languages, Trophy, Settings, ChevronLeft, ChevronRight, Sparkles, User } from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


interface SidebarProps {
  activeRoute?: string;
}

const NAV_GROUPS = [
  {
    label: 'STUDY',
    items: [
      { id: 'nav-dashboard', label: 'Dashboard', icon: LayoutDashboard, route: '/home-dashboard', badge: null },
      { id: 'nav-study', label: 'Study Content', icon: BookOpen, route: '/study-content', badge: null },
      { id: 'nav-tests', label: 'My Tests', icon: FlaskConical, route: '/home-dashboard', badge: '3' },
      { id: 'nav-doubts', label: 'Doubt Solver', icon: MessageCircleQuestion, route: '/home-dashboard', badge: '2' },
    ],
  },
  {
    label: 'LEARNING',
    items: [
      { id: 'nav-languages', label: 'Languages', icon: Languages, route: '/study-content', badge: null },
      { id: 'nav-achievements', label: 'Achievements', icon: Trophy, route: '/home-dashboard', badge: null },
      { id: 'nav-ai', label: 'AI Guide', icon: Sparkles, route: '/home-dashboard', badge: null },
    ],
  },
  {
    label: 'ACCOUNT',
    items: [
      { id: 'nav-settings', label: 'Settings', icon: Settings, route: '/home-dashboard', badge: null },
    ],
  },
];

export default function Sidebar({ activeRoute }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-r border-border bg-card transition-all duration-300 ease-in-out flex-shrink-0 ${
          collapsed ? 'w-[68px]' : 'w-[240px]'
        }`}
      >
        {/* Logo */}
        <div className={`flex items-center h-16 border-b border-border px-4 ${collapsed ? 'justify-center' : 'gap-2'}`}>
          <AppLogo size={32} />
          {!collapsed && (
            <span className="font-semibold text-base text-foreground tracking-tight">StudyAI</span>
          )}
        </div>

        {/* Nav Groups */}
        <nav className="flex-1 overflow-y-auto scrollbar-thin py-4 px-2 space-y-5">
          {NAV_GROUPS.map((group) => (
            <div key={`group-${group.label}`}>
              {!collapsed && (
                <p className="text-[10px] font-semibold text-muted-foreground tracking-widest uppercase px-2 mb-1.5">
                  {group.label}
                </p>
              )}
              <ul className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeRoute === item.route;
                  return (
                    <li key={item.id}>
                      <Link
                        href={item.route}
                        className={`sidebar-link relative group ${isActive ? 'sidebar-link-active' : ''} ${collapsed ? 'justify-center px-2' : ''}`}
                        title={collapsed ? item.label : undefined}
                      >
                        <Icon size={18} className="flex-shrink-0" />
                        {!collapsed && <span className="flex-1">{item.label}</span>}
                        {!collapsed && item.badge && (
                          <span className="badge bg-primary-soft text-primary font-semibold">{item.badge}</span>
                        )}
                        {collapsed && item.badge && (
                          <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-primary" />
                        )}
                        {collapsed && (
                          <div className="absolute left-full ml-2 px-2 py-1 bg-foreground text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity duration-150">
                            {item.label}
                          </div>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>

        {/* User + Collapse */}
        <div className="border-t border-border p-2 space-y-1">
          {!collapsed && (
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-muted transition-colors cursor-pointer">
              <div className="w-7 h-7 rounded-full bg-primary-soft flex items-center justify-center flex-shrink-0">
                <User size={14} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">Priya Sharma</p>
                <p className="text-[10px] text-muted-foreground truncate">priya@studyai.app</p>
              </div>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-all duration-150 ${collapsed ? 'justify-center' : ''}`}
          >
            {collapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={16} /><span>Collapse</span></>}
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border flex items-center justify-around px-2 py-2 safe-area-pb">
        {[
          { id: 'mob-dashboard', label: 'Home', icon: LayoutDashboard, route: '/home-dashboard' },
          { id: 'mob-study', label: 'Study', icon: BookOpen, route: '/study-content' },
          { id: 'mob-tests', label: 'Tests', icon: FlaskConical, route: '/home-dashboard' },
          { id: 'mob-doubts', label: 'Doubts', icon: MessageCircleQuestion, route: '/home-dashboard' },
          { id: 'mob-ai', label: 'AI Guide', icon: Sparkles, route: '/home-dashboard' },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = activeRoute === item.route;
          return (
            <Link
              key={item.id}
              href={item.route}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-xl transition-all duration-150 ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <Icon size={20} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </>
  );
}